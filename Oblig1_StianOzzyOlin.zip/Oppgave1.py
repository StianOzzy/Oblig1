# Oblig 1, Oppgave 1

# Skriver "Hello, world!" i konsollet
print("Hello, world!")