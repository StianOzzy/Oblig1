# Oblig 1, Oppgave 4

# Definerer verdien til a, b og c som 6, 3 og 2
a, b, c = 6, 3, 2

# Skriver ut svaret på de ulike regneoperasjonene
print("Oppgave a) ", a+b*c)
print("Oppgave b) ", (a+b)*c)
print("Oppgave c) ", a/b/c)
print("Oppgave d) ", a/(b/c))