# Oblig 1, Oppgave 3

# Definerer en variabel som kan tildeles verdi ifra user-input
første_tall = float(input("Skriv det første tallet ditt:\n"))
andre_tall = float(input("Skriv det andre tallet ditt\n"))

# Skriver ut svaret på de ulike regneoperasjonene
print(første_tall * andre_tall, "\n")
print(første_tall / andre_tall, "\n")
print(første_tall + andre_tall, "\n")
print(første_tall - andre_tall, "\n")
print(første_tall % andre_tall, "\n")
print(første_tall ** andre_tall, "\n")
print(første_tall // andre_tall, "\n")