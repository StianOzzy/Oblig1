# Oblig 1, Oppgave 5

# Antall konsumerte småkaker per person
pers1_konsum = 5
pers2_konsum = 9
pers3_konsum = 2.5
pers4_konsum = 21
pers5_konsum = 0

# Antall personer som er med i utregningen
antall_pers = 5

# Kalkulering av totalt antall konsumerte småkaker
sum_konsum = pers1_konsum + pers2_konsum + pers3_konsum + pers4_konsum + pers5_konsum

# Skriver totalt antall konsumerte småkaker fordelt på antall personer (gjennomsnitt)
print(int(sum_konsum/antall_pers))
