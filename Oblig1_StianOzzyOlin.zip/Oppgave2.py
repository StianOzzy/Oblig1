# Oblig 1, Oppgave 2

# Bestemmer verdiene til variablene fornavn, etternavn og alder
fornavn = "Stian Ozzy"
etternavn = "Olin"
alder = 22

# Skriver ut sitatet fra oppgaveteksten, med variablene som jeg bestemte over
print(f"Hei. Jeg heter {fornavn} {etternavn} og er {alder} år gammel")